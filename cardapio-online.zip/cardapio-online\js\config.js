// =====================================================================
//  CONFIGURAÇÃO DO FIREBASE
//  1. Crie um projeto em https://console.firebase.google.com
//  2. Adicione um "App Web" e copie o objeto firebaseConfig para baixo
//  3. Ative Authentication (E-mail/senha) e Firestore Database
//
//  Enquanto apiKey estiver vazia, o sistema roda em MODO DEMO:
//  os dados ficam salvos só neste navegador (localStorage), ótimo para testar.
// =====================================================================
export const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};

export const DEMO = !firebaseConfig.apiKey;

// Versão do SDK do Firebase carregada via CDN (não precisa de npm)
export const FIREBASE_SDK = "https://www.gstatic.com/firebasejs/10.12.2";
