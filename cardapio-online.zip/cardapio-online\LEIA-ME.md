# Cardápio Online

Cardápio digital com painel administrativo completo para restaurante e lanchonete.
Feito em **HTML, CSS e JavaScript puro**, com **Firebase** (banco em tempo real e login), instalável como **PWA** e publicado na **Vercel**.

| Endereço | O que é |
|---|---|
| `/` | Cardápio do cliente |
| `/?mesa=5` | Cardápio no modo mesa (aberto pelo QR Code) |
| `/pedido.html?id=...` | Acompanhamento do pedido em tempo real |
| `/admin/` | Painel administrativo |
| `/p/ID` | Link de produto com prévia (foto e preço) no WhatsApp |

---

## 1. Testar agora (modo demo, sem Firebase)

Enquanto `js/config.js` estiver com `apiKey` vazia, o sistema roda em **modo demo**: os dados ficam no navegador e já vem um cardápio de exemplo.

Precisa abrir por um servidor local (abrir o arquivo com duplo clique não funciona por causa dos módulos JavaScript):

```bash
npx serve .
```

Abra `http://localhost:3000` (cardápio) e `http://localhost:3000/admin/` (painel, qualquer e-mail e senha com 6+ caracteres).
Dica: deixe o cardápio e o painel em abas lado a lado. Os pedidos aparecem no painel na hora.

---

## 2. Configurar o Firebase (grátis)

1. Acesse <https://console.firebase.google.com> › **Adicionar projeto**.
2. **Authentication** › Começar › ative **E-mail/senha**.
3. **Firestore Database** › Criar banco de dados › modo **produção** › região `southamerica-east1` (São Paulo).
4. Em **Firestore › Regras**, apague tudo, cole o conteúdo do arquivo `firestore.rules` e clique em **Publicar**.
5. **Configurações do projeto** (engrenagem) › Seus apps › ícone **Web `</>`** › registre o app e copie o objeto `firebaseConfig`.
6. Cole os valores em `js/config.js`.
7. Em **Authentication › Configurações › Domínios autorizados**, adicione o domínio da Vercel (ex.: `seu-cardapio.vercel.app`) e seu domínio próprio, se tiver.

> Não é preciso ativar o Firebase Storage (que hoje exige plano pago): as fotos são comprimidas no navegador e salvas direto no Firestore.

### Primeiro acesso
Abra `/admin/`, clique em **Primeiro acesso**, informe nome, e-mail e senha. Essa conta vira o **dono**. As regras impedem criar um segundo dono por aqui.
Depois, em **Configurações › Link e QR do cardápio**, clique em **Carregar dados de exemplo** se quiser começar com um cardápio pronto para editar.

---

## 3. Publicar na Vercel

1. Crie uma conta em <https://vercel.com>.
2. Envie esta pasta (pelo GitHub ou pela CLI):
   ```bash
   npx vercel
   ```
   Framework: **Other**. Não há comando de build.
3. Em **Settings › Environment Variables**, crie (para a prévia de produtos no WhatsApp):
   - `FIREBASE_PROJECT_ID` = o `projectId` do seu `config.js`
   - `FIREBASE_API_KEY` = a `apiKey` do seu `config.js`
4. Faça um novo deploy (`npx vercel --prod`).
5. Troque `SEU-DOMINIO` em `robots.txt` e `sitemap.xml` pelo endereço real.

---

## 4. Funcionalidades

**Cliente**
- Cardápio com categorias fixas no topo, busca, destaques, selos (Mais vendido, Promoção, Novo, Vegano, Picante) e preço promocional
- Adicionais obrigatórios e opcionais (mínimo e máximo), observação por item
- Sacola com **upsell inteligente** (sugere o que falta, como bebida ou sobremesa)
- **Cupons** (percentual, valor fixo, frete grátis, mínimo, validade, limite de usos)
- **Fidelidade**: a cada pedido finalizado o cliente ganha 1 ponto pelo WhatsApp; ao atingir a meta, usa a recompensa
- Delivery (taxa por bairro e pedido mínimo) ou retirada
- **Pagamento sempre na entrega/retirada**: o cliente só escolhe a forma; no dinheiro, informa se precisa de troco e para quanto
- **Status em tempo real** no site e na página do pedido (com som e vibração ao mudar)
- **QR Code por mesa**: pedir, chamar garçom e pedir a conta (escolhendo a forma de pagamento)
- **Horário automático** (abre e fecha sozinho, inclusive virando a madrugada)
- **Compartilhar produto** e o cardápio (WhatsApp ou compartilhamento nativo do celular)
- **SEO + Open Graph** + dados estruturados (schema.org Restaurant/Menu)
- PWA: instala na tela inicial e abre mesmo com internet ruim

**Painel**
- Dashboard: faturamento, pedidos, ticket médio, gráfico, mais vendidos, tipos e formas de pagamento
- Pedidos em kanban em tempo real com **alerta sonoro** repetido e notificação, impressão de comanda (58/80 mm), cancelamento com motivo
- Mesas: chamados em tempo real, conta da mesa, fechar conta, QR Codes para imprimir
- Cardápio: produtos (foto, emoji, promoção, selos, adicionais, upsell, esgotado em 1 clique), categorias com ordem, grupos de adicionais
- Cupons e **Clientes e fidelidade** (histórico, pontos, exportação CSV)
- **Financeiro**: resumo do mês, **contas a pagar** e **contas a receber** com parcelas, recorrência mensal, vencidas e CSV
- Entrega: delivery/retirada, tempos, mínimo e taxas por bairro
- Configurações: dados da loja, horários, **cores da marca**, formas de pagamento, upsell, SEO, equipe (dono e atendente), link e QR do cardápio
- Botão para pausar a loja na hora

---

## 5. Estrutura

```
index.html  pedido.html  offline.html  admin/index.html
css/        base.css (tema e componentes) · cliente.css · admin.css
js/         config.js (Firebase) · db.js (dados: Firebase ou demo) · utils.js · seed.js
            cliente.js · pedido.js
js/admin/   app.js (menu, login, alertas) · pedidos · mesas · cardapio · cupons
            clientes · financeiro · dashboard · entrega · loja · acoes
api/        produto.js e imagem.js (prévia de links na Vercel)
sw.js  manifest.json  vercel.json  firestore.rules  robots.txt  sitemap.xml  assets/
```

## 6. Dicas

- **Imagem de compartilhamento**: substitua `assets/og-image.png` (1200×630) por uma foto da sua loja.
- **Ícones do app**: substitua `assets/icon-192.png`, `icon-512.png` e `icon.svg` pelo seu logo.
- **Atualizou o site?** Aumente `VERSAO` em `sw.js` (ex.: `co-v2`) para os celulares baixarem a versão nova.
- **Som de pedidos**: no painel, clique em **Ativar som** uma vez (o navegador exige um clique para liberar áudio). Deixe a aba do painel aberta no computador ou tablet do balcão.
